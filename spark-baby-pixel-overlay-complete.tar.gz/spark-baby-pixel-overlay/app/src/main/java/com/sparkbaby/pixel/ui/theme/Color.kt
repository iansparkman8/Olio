package com.sparkbaby.pixel.ui.theme

import androidx.compose.ui.graphics.Color

val SparkPurple = Color(0xFF9D4EDD)
val SparkCyan = Color(0xFF00F5FF)
val SparkPink = Color(0xFFFF6EC7)
val PixelBg = Color(0xFF1A1A2E)
val PixelSurface = Color(0xFF16213E)
val PixelOnSurface = Color(0xFFE0E0E0)
