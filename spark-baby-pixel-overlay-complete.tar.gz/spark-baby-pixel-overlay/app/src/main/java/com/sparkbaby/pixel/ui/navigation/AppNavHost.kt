package com.sparkbaby.pixel.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.sparkbaby.pixel.ui.screens.HomeScreen
import com.sparkbaby.pixel.ui.screens.PermissionWizardScreen

@Composable
fun AppNavHost(navController: NavHostController) {
    NavHost(navController, startDestination = Routes.PERMISSION_WIZARD) {
        composable(Routes.PERMISSION_WIZARD) {
            PermissionWizardScreen(
                onContinue = { navController.navigate(Routes.HOME) { popUpTo(Routes.PERMISSION_WIZARD) { inclusive = true } } }
            )
        }
        composable(Routes.HOME) {
            HomeScreen(
                onStartOverlay = { /* Service started from here in full impl */ },
                onOpenControl = { navController.navigate(Routes.CONTROL_PANEL) }
            )
        }
        composable(Routes.CONTROL_PANEL) {
            androidx.compose.material3.Text("Control Panel - Tap sprite to open (demo)")
        }
    }
}
