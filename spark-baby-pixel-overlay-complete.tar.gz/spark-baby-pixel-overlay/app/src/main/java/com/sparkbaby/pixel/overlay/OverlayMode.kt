package com.sparkbaby.pixel.overlay

enum class OverlayMode {
    PASSIVE,    // Small floating sprite only
    EXPANDED    // Control bubble/panel open
}
