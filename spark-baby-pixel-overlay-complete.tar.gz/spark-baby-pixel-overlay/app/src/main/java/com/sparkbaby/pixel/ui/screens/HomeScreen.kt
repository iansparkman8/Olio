package com.sparkbaby.pixel.ui.screens

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.sparkbaby.pixel.overlay.SparkOverlayService

@Composable
fun HomeScreen(onStartOverlay: () -> Unit, onOpenControl: () -> Unit) {
    val context = LocalContext.current

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("✨ Spark Baby", style = MaterialTheme.typography.headlineLarge)
        Text("Your pixel companion is ready to float above apps.")

        Button(onClick = {
            context.startService(Intent(context, SparkOverlayService::class.java))
            onStartOverlay()
        }) {
            Text("START FLOATING OVERLAY")
        }

        Button(onClick = onOpenControl) {
            Text("Open Control Panel")
        }

        Text(
            "Long-press the sprite to drag. Tap to interact.\nShe will wander and react to commands.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
