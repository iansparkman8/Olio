package com.sparkbaby.pixel.ai

import com.sparkbaby.pixel.avatar.AvatarForm
import com.sparkbaby.pixel.avatar.MoodState
import com.sparkbaby.pixel.data.LessonEntity
import com.sparkbaby.pixel.data.MemoryEntity

interface AiProvider {
    suspend fun sendMessage(
        userMessage: String,
        memories: List<MemoryEntity>,
        lessons: List<LessonEntity>,
        currentMood: MoodState,
        currentForm: AvatarForm
    ): AiReply
}

data class AiReply(val text: String, val newMood: MoodState? = null)
