package com.sparkbaby.pixel.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.sparkbaby.pixel.overlay.OverlayPermissionHelper

@Composable
fun PermissionWizardScreen(onContinue: () -> Unit) {
    val context = LocalContext.current
    var hasOverlay by remember { mutableStateOf(OverlayPermissionHelper.hasOverlayPermission(context)) }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Text("✨ Spark Baby Setup", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
        Text("Grant Draw over other apps so she can float above everything.")

        if (!hasOverlay) {
            Button(onClick = {
                OverlayPermissionHelper.requestOverlayPermission(context)
            }) {
                Text("Open Draw-Over Settings")
            }
        } else {
            Text("Permission granted ✓", color = MaterialTheme.colorScheme.secondary)
        }

        Button(
            onClick = onContinue,
            enabled = hasOverlay
        ) {
            Text(if (hasOverlay) "Start Spark Baby" else "Grant permission first")
        }
    }
}
