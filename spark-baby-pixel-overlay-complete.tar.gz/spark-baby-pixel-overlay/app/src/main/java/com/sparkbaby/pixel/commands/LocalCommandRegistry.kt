package com.sparkbaby.pixel.commands

object LocalCommandRegistry {
    val commands = listOf(
        "come here", "go away", "hide", "sleep", "wake up", "dance",
        "listen", "be happy", "be curious", "open chat", "change form"
    )
}
