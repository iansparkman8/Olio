package com.sparkbaby.pixel

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build

class SparkBabyApplication : Application() {

    companion object {
        const val OVERLAY_CHANNEL_ID = "spark_baby_overlay_channel"
        const val OVERLAY_NOTIFICATION_ID = 1001
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                OVERLAY_CHANNEL_ID,
                "Spark Baby Overlay",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps your pixel companion alive and floating"
                setShowBadge(false)
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }
}
