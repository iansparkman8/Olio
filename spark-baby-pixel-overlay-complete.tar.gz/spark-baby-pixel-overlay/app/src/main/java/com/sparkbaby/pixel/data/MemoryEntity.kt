package com.sparkbaby.pixel.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val content: String,
    val category: String = "general",
    val createdAt: Long = System.currentTimeMillis(),
    val importance: Int = 1
)
