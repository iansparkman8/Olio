package com.sparkbaby.pixel.ui

import androidx.compose.runtime.Composable
import androidx.navigation.compose.rememberNavController
import com.sparkbaby.pixel.ui.navigation.AppNavHost

@Composable
fun SparkBabyApp() {
    val navController = rememberNavController()
    AppNavHost(navController)
}
