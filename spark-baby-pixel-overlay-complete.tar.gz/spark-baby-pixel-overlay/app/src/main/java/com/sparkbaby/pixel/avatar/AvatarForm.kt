package com.sparkbaby.pixel.avatar

enum class AvatarForm(val displayName: String, val unlockLessons: Int = 0) {
    BABY_SPRITE("Baby Sprite", 0),
    FAIRY_SPRITE("Fairy Sprite", 5),
    CYBER_FAIRY("Cyber Fairy", 0),
    FIREFLY("Firefly", 0),
    PIXEL_ANGEL("Pixel Angel", 50),
    GLITCH_FAIRY("Glitch Fairy", 0)
}
