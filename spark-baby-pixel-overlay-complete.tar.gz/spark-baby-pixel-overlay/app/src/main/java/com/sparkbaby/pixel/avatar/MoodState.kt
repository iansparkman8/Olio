package com.sparkbaby.pixel.avatar

enum class MoodState {
    IDLE, HAPPY, CURIOUS, THINKING, LISTENING, SLEEPY, ALERT, DANCING, PROUD, CONFUSED, GLITCHY
}
