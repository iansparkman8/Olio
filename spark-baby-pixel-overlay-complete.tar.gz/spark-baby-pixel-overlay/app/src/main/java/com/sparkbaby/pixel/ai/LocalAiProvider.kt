package com.sparkbaby.pixel.ai

import com.sparkbaby.pixel.avatar.AvatarForm
import com.sparkbaby.pixel.avatar.MoodState
import com.sparkbaby.pixel.data.LessonEntity
import com.sparkbaby.pixel.data.MemoryEntity

class LocalAiProvider : AiProvider {
    override suspend fun sendMessage(
        userMessage: String,
        memories: List<MemoryEntity>,
        lessons: List<LessonEntity>,
        currentMood: MoodState,
        currentForm: AvatarForm
    ): AiReply {
        val lower = userMessage.lowercase()
        val reply = when {
            "hello" in lower || "hi" in lower -> "Hi! I'm Spark Baby ✨ What are we doing today?"
            "how are you" in lower -> "I'm feeling ${currentMood.name.lowercase()} and sparkly!"
            "dance" in lower -> "Okay! *does a little pixel dance*"
            else -> "I heard you say \"$userMessage\". Tell me more or teach me something new!"
        }
        return AiReply(reply, currentMood)
    }
}
