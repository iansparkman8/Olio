package com.sparkbaby.pixel.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [MemoryEntity::class, LessonEntity::class],
    version = 1,
    exportSchema = false
)
abstract class SparkDatabase : RoomDatabase() {
    abstract fun memoryDao(): MemoryDao
    abstract fun lessonDao(): LessonDao

    companion object {
        @Volatile private var INSTANCE: SparkDatabase? = null

        fun getInstance(context: Context): SparkDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    SparkDatabase::class.java,
                    "spark_baby_db"
                ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
            }
        }
    }
}
