package com.sparkbaby.pixel.ui.navigation

object Routes {
    const val PERMISSION_WIZARD = "permission_wizard"
    const val HOME = "home"
    const val CONTROL_PANEL = "control_panel"
}
