package com.sparkbaby.pixel.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = SparkPurple,
    secondary = SparkCyan,
    tertiary = SparkPink,
    background = PixelBg,
    surface = PixelSurface,
    onPrimary = Color.White,
    onSecondary = Color.Black,
    onBackground = PixelOnSurface,
    onSurface = PixelOnSurface
)

@Composable
fun SparkBabyTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = SparkTypography,
        content = content
    )
}
