package com.sparkbaby.pixel.overlay

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.sparkbaby.pixel.SparkBabyApplication
import com.sparkbaby.pixel.avatar.MoodState
import kotlinx.coroutines.*

class SparkOverlayService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var windowManager: WindowManager
    private var pixelView: PixelCompanionView? = null
    private var currentMode = OverlayMode.PASSIVE

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(
            SparkBabyApplication.OVERLAY_NOTIFICATION_ID,
            createNotification()
        )
        if (pixelView == null) {
            createFloatingView()
        }
        return START_STICKY
    }

    private fun createNotification() = NotificationCompat.Builder(this, SparkBabyApplication.OVERLAY_CHANNEL_ID)
        .setContentTitle(getString(R.string.overlay_notification_title))
        .setContentText(getString(R.string.overlay_notification_text))
        .setSmallIcon(android.R.drawable.ic_menu_view)
        .setOngoing(true)
        .build()

    private fun createFloatingView() {
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 300
            width = (96 * resources.displayMetrics.density).toInt()
            height = (96 * resources.displayMetrics.density).toInt()
        }

        pixelView = PixelCompanionView(this, params, windowManager, serviceScope) { newMode ->
            currentMode = newMode
            // TODO: expand to larger panel when EXPANDED
        }.also {
            windowManager.addView(it, params)
            it.setMood(MoodState.IDLE)
            it.startIdleBehavior()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        pixelView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
