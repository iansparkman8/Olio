package com.sparkbaby.pixel.overlay

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.content.res.ResourcesCompat
import com.sparkbaby.pixel.R
import com.sparkbaby.pixel.avatar.MoodState
import kotlinx.coroutines.*
import kotlin.math.abs
import kotlin.random.Random

class PixelCompanionView(
    context: Context,
    private val params: WindowManager.LayoutParams,
    private val windowManager: WindowManager,
    private val scope: CoroutineScope,
    private val onModeChange: (OverlayMode) -> Unit
) : View(context) {

    private var currentMood = MoodState.IDLE
    private var currentFrame = 0
    private var spriteSheet: Bitmap? = null
    private var frameWidth = 32
    private var frameHeight = 32
    private var frameCount = 8
    private var fps = 6
    private var lastFrameTime = 0L
    private var isDragging = false
    private var lastX = 0f
    private var lastY = 0f

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        isFilterBitmap = false // nearest neighbor pixel feel
    }

    init {
        loadSpriteForMood(currentMood)
        setBackgroundColor(Color.TRANSPARENT)
    }

    private fun loadSpriteForMood(mood: MoodState) {
        val resId = when (mood) {
            MoodState.HAPPY -> R.drawable.spark_baby_happy
            MoodState.CURIOUS -> R.drawable.spark_baby_curious
            MoodState.THINKING -> R.drawable.spark_baby_thinking
            MoodState.LISTENING -> R.drawable.spark_baby_listening
            MoodState.SLEEPY -> R.drawable.spark_baby_sleepy
            MoodState.ALERT -> R.drawable.spark_baby_alert
            MoodState.DANCING -> R.drawable.spark_baby_dancing
            else -> R.drawable.spark_baby_idle
        }
        try {
            val opts = BitmapFactory.Options().apply { inScaled = false }
            spriteSheet = BitmapFactory.decodeResource(resources, resId, opts)
            frameCount = when (mood) {
                MoodState.DANCING -> 12
                MoodState.LISTENING, MoodState.ALERT -> 8
                else -> 8
            }
            currentFrame = 0
        } catch (e: Exception) {
            // Fallback to idle if missing
            spriteSheet = BitmapFactory.decodeResource(resources, R.drawable.spark_baby_idle)
        }
    }

    fun setMood(mood: MoodState) {
        if (currentMood != mood) {
            currentMood = mood
            loadSpriteForMood(mood)
            invalidate()
        }
    }

    fun startIdleBehavior() {
        scope.launch {
            while (isAttachedToWindow) {
                delay(120)
                val now = System.currentTimeMillis()
                if (now - lastFrameTime > (1000 / fps)) {
                    currentFrame = (currentFrame + 1) % frameCount
                    lastFrameTime = now
                    invalidate()
                }
                // Simple idle wandering every ~8 seconds
                if (Random.nextInt(80) == 0 && currentMood == MoodState.IDLE) {
                    wanderSlightly()
                }
            }
        }
    }

    private fun wanderSlightly() {
        val newX = params.x + Random.nextInt(-40, 41)
        val newY = params.y + Random.nextInt(-30, 31)
        params.x = newX.coerceIn(0, (context.resources.displayMetrics.widthPixels - width))
        params.y = newY.coerceIn(80, (context.resources.displayMetrics.heightPixels - height - 120))
        try {
            windowManager.updateViewLayout(this, params)
        } catch (_: Exception) {}
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        spriteSheet?.let { sheet ->
            val src = Rect(
                currentFrame * frameWidth,
                0,
                (currentFrame + 1) * frameWidth,
                frameHeight
            )
            val dst = Rect(0, 0, width, height)
            canvas.drawBitmap(sheet, src, dst, paint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.rawX
                lastY = event.rawY
                isDragging = false
                performClick()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - lastX
                val dy = event.rawY - lastY
                if (abs(dx) > 8 || abs(dy) > 8) isDragging = true
                if (isDragging) {
                    params.x = (params.x + dx).toInt()
                    params.y = (params.y + dy).toInt()
                    windowManager.updateViewLayout(this, params)
                    lastX = event.rawX
                    lastY = event.rawY
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!isDragging) {
                    // Tap → open expanded controls (for now just change mood + sparkle)
                    setMood(MoodState.HAPPY)
                    onModeChange(OverlayMode.EXPANDED)
                    // In full version: show expanded panel window
                } else {
                    // Snap to edge when released
                    snapToEdge()
                }
                isDragging = false
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun snapToEdge() {
        val screenW = context.resources.displayMetrics.widthPixels
        val targetX = if (params.x < screenW / 2) 40 else screenW - width - 40
        params.x = targetX
        try {
            windowManager.updateViewLayout(this, params)
        } catch (_: Exception) {}
        setMood(MoodState.IDLE)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
