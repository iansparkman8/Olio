# Room
-keep class com.sparkbaby.pixel.data.** { *; }
-keep class androidx.room.** { *; }
