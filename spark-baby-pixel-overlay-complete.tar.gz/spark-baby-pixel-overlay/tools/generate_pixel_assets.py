#!/usr/bin/env python3
"""
Spark Baby Pixel Asset Generator
Generates real pixel-art PNG sprite sheets and simple WAV sound effects.
Run this once to populate res/drawable-nodpi/ and res/raw/
"""

import os
import math
import wave
import struct
from PIL import Image, ImageDraw

# Output paths
DRAWABLE_DIR = "app/src/main/res/drawable-nodpi"
RAW_DIR = "app/src/main/res/raw"
os.makedirs(DRAWABLE_DIR, exist_ok=True)
os.makedirs(RAW_DIR, exist_ok=True)

# Color palette (neon pixel fairy)
PURPLE = (157, 78, 221)
CYAN = (0, 245, 255)
PINK = (255, 110, 199)
DARK = (26, 26, 46)
WHITE = (255, 255, 255)
YELLOW = (255, 255, 100)
ORANGE = (255, 180, 80)

def create_base_fairy(frame, mood="idle"):
    """Create a 32x32 pixel fairy sprite for one frame"""
    img = Image.new('RGBA', (32, 32), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Body (dress)
    body_color = PURPLE
    if mood == "happy":
        body_color = PINK
    elif mood == "sleepy":
        body_color = (100, 80, 150)
    elif mood == "glitch":
        body_color = CYAN if frame % 2 == 0 else PURPLE
    
    # Head
    draw.rectangle([12, 6, 20, 14], fill=body_color)  # head
    # Eyes (glow)
    eye_y = 9
    if mood == "sleepy":
        draw.line([(14, eye_y+1), (15, eye_y+1)], fill=CYAN, width=1)
        draw.line([(17, eye_y+1), (18, eye_y+1)], fill=CYAN, width=1)
    elif mood == "happy":
        draw.ellipse([13, eye_y, 16, eye_y+3], fill=CYAN)
        draw.ellipse([17, eye_y, 20, eye_y+3], fill=CYAN)
    else:
        draw.rectangle([13, eye_y, 15, eye_y+2], fill=CYAN)
        draw.rectangle([17, eye_y, 19, eye_y+2], fill=CYAN)
    
    # Body / dress
    draw.polygon([(12, 14), (20, 14), (22, 26), (10, 26)], fill=body_color)
    
    # Wings (flapping based on frame)
    wing_offset = math.sin(frame * 0.8) * 2
    if mood == "dancing":
        wing_offset = math.sin(frame * 1.5) * 3
    
    # Left wing
    draw.polygon([
        (10, 12), 
        (4, 8 + wing_offset), 
        (2, 16 + wing_offset), 
        (8, 18)
    ], fill=CYAN)
    # Right wing
    draw.polygon([
        (22, 12), 
        (28, 8 + wing_offset), 
        (30, 16 + wing_offset), 
        (24, 18)
    ], fill=CYAN)
    
    # Sparkle / antenna
    if mood in ["curious", "thinking", "alert"]:
        draw.line([(16, 6), (16, 2)], fill=YELLOW, width=1)
        draw.ellipse([14, 0, 18, 4], fill=YELLOW)
    
    # Legs / bob
    bob = 1 if frame % 2 == 0 else 0
    draw.line([(13, 26), (13, 29 + bob)], fill=PURPLE, width=1)
    draw.line([(19, 26), (19, 29 + bob)], fill=PURPLE, width=1)
    
    return img

def generate_sprite_sheet(name, moods, frame_count, width, height=32):
    """Generate horizontal strip sprite sheet"""
    sheet = Image.new('RGBA', (width, height), (0, 0, 0, 0))
    for i in range(frame_count):
        mood = moods[i % len(moods)] if isinstance(moods, list) else moods
        frame = create_base_fairy(i, mood)
        sheet.paste(frame, (i * 32, 0))
    path = os.path.join(DRAWABLE_DIR, f"{name}.png")
    sheet.save(path, "PNG")
    print(f"Generated: {path}")
    return path

def generate_shadow():
    img = Image.new('RGBA', (32, 12), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    # Simple oval shadow
    draw.ellipse([4, 4, 28, 10], fill=(0, 0, 0, 80))
    path = os.path.join(DRAWABLE_DIR, "spark_baby_shadow.png")
    img.save(path, "PNG")
    print(f"Generated: {path}")

def generate_ui_elements():
    # Simple 9patch-style panel (center stretchable area marked)
    panel = Image.new('RGBA', (48, 48), (0, 0, 0, 0))
    draw = ImageDraw.Draw(panel)
    # Outer border
    draw.rectangle([0, 0, 47, 47], outline=CYAN, width=2)
    draw.rectangle([2, 2, 45, 45], outline=PURPLE, width=1)
    # Inner fill hint
    draw.rectangle([6, 6, 41, 41], fill=(30, 30, 60, 200))
    path = os.path.join(DRAWABLE_DIR, "ui_pixel_panel_9patch.png")
    panel.save(path, "PNG")
    print(f"Generated: {path}")

    # Button
    btn = Image.new('RGBA', (32, 32), (0, 0, 0, 0))
    draw = ImageDraw.Draw(btn)
    draw.rectangle([0, 0, 31, 31], outline=PINK, width=2)
    draw.rectangle([2, 2, 29, 29], fill=(60, 20, 80))
    path = os.path.join(DRAWABLE_DIR, "ui_pixel_button_9patch.png")
    btn.save(path, "PNG")
    print(f"Generated: {path}")

    # Bubble tail
    tail = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    draw = ImageDraw.Draw(tail)
    draw.polygon([(0, 0), (16, 0), (8, 16)], fill=CYAN)
    path = os.path.join(DRAWABLE_DIR, "ui_pixel_bubble_tail.png")
    tail.save(path, "PNG")
    print(f"Generated: {path}")

    # Glow ring
    glow = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
    draw = ImageDraw.Draw(glow)
    draw.ellipse([4, 4, 60, 60], outline=CYAN, width=3)
    path = os.path.join(DRAWABLE_DIR, "ui_pixel_glow_ring.png")
    glow.save(path, "PNG")
    print(f"Generated: {path}")

    # Cursor
    cur = Image.new('RGBA', (8, 16), (0, 0, 0, 0))
    draw = ImageDraw.Draw(cur)
    draw.line([(0, 0), (0, 15)], fill=WHITE, width=1)
    draw.line([(1, 0), (7, 0)], fill=WHITE, width=1)
    path = os.path.join(DRAWABLE_DIR, "ui_pixel_command_cursor.png")
    cur.save(path, "PNG")
    print(f"Generated: {path}")

def generate_form_sheets():
    forms = [
        "form_baby_sprite_idle",
        "form_fairy_sprite_idle", 
        "form_cyber_fairy_idle",
        "form_firefly_idle",
        "form_pixel_angel_idle",
        "form_glitch_fairy_idle"
    ]
    for form in forms:
        # Slight color variation per form
        mood = "idle"
        if "cyber" in form:
            mood = "alert"
        elif "glitch" in form:
            mood = "glitch"
        elif "angel" in form:
            mood = "proud"
        generate_sprite_sheet(form, mood, 8, 256)

def generate_animation_json(name, sprite, frame_count=8, fps=6, loop=True):
    data = {
        "name": name,
        "sprite": sprite,
        "frameWidth": 32,
        "frameHeight": 32,
        "frameCount": frame_count,
        "fps": fps,
        "loop": loop,
        "scale": 3,
        "anchorX": 16,
        "anchorY": 26,
        "hitbox": {"x": 6, "y": 4, "width": 20, "height": 24}
    }
    import json
    path = os.path.join(RAW_DIR, f"anim_{name}.json")
    with open(path, "w") as f:
        json.dump(data, f, indent=2)
    print(f"Generated: {path}")

def generate_avatar_forms_json():
    data = {
        "forms": [
            {"id": "BABY_SPRITE", "name": "Baby Sprite", "unlock": "Default", "lessons": 0},
            {"id": "FAIRY_SPRITE", "name": "Fairy Sprite", "unlock": "5 lessons saved", "lessons": 5},
            {"id": "CYBER_FAIRY", "name": "Cyber Fairy", "unlock": "Connect AI provider", "lessons": 0},
            {"id": "FIREFLY", "name": "Firefly", "unlock": "20 conversations", "lessons": 0},
            {"id": "PIXEL_ANGEL", "name": "Pixel Angel", "unlock": "50 lessons saved", "lessons": 50},
            {"id": "GLITCH_FAIRY", "name": "Glitch Fairy", "unlock": "Manual from Settings", "lessons": 0}
        ]
    }
    import json
    path = os.path.join(RAW_DIR, "avatar_forms.json")
    with open(path, "w") as f:
        json.dump(data, f, indent=2)
    print(f"Generated: {path}")

def generate_wav(name, frequency=440, duration=0.4, volume=0.3):
    """Generate simple sine wave tone as WAV"""
    path = os.path.join(RAW_DIR, f"{name}.wav")
    sample_rate = 22050
    n_samples = int(sample_rate * duration)
    
    with wave.open(path, 'w') as wav_file:
        wav_file.setnchannels(1)
        wav_file.setsampwidth(2)
        wav_file.setframerate(sample_rate)
        
        for i in range(n_samples):
            t = float(i) / sample_rate
            # Simple sine + slight decay
            value = int(volume * 32767 * math.sin(2 * math.pi * frequency * t) * (1 - t/duration))
            if "sparkle" in name:
                value = int(value * (1 + 0.3 * math.sin(2 * math.pi * 1200 * t)))
            data = struct.pack('<h', value)
            wav_file.writeframes(data)
    print(f"Generated: {path}")

# === MAIN ===
if __name__ == "__main__":
    print("=== Generating Spark Baby Pixel Assets ===")
    
    # Main avatar sheets
    generate_sprite_sheet("spark_baby_idle", "idle", 8, 256)
    generate_sprite_sheet("spark_baby_blink", ["idle", "sleepy"], 4, 128)
    generate_sprite_sheet("spark_baby_happy", "happy", 8, 256)
    generate_sprite_sheet("spark_baby_curious", "curious", 8, 256)
    generate_sprite_sheet("spark_baby_thinking", "thinking", 8, 256)
    generate_sprite_sheet("spark_baby_listening", "alert", 8, 256)
    generate_sprite_sheet("spark_baby_sleepy", "sleepy", 8, 256)
    generate_sprite_sheet("spark_baby_alert", "alert", 8, 256)
    generate_sprite_sheet("spark_baby_dancing", "dancing", 12, 384)
    generate_sprite_sheet("spark_baby_sparkle_fx", "curious", 8, 256)
    generate_shadow()
    
    # Form variants
    generate_form_sheets()
    
    # UI elements
    generate_ui_elements()
    
    # Animation metadata
    generate_animation_json("idle", "spark_baby_idle", 8, 5, True)
    generate_animation_json("blink", "spark_baby_blink", 4, 8, False)
    generate_animation_json("happy", "spark_baby_happy", 8, 7, True)
    generate_animation_json("curious", "spark_baby_curious", 8, 6, True)
    generate_animation_json("thinking", "spark_baby_thinking", 8, 4, True)
    generate_animation_json("listening", "spark_baby_listening", 8, 6, True)
    generate_animation_json("sleepy", "spark_baby_sleepy", 8, 3, True)
    generate_animation_json("alert", "spark_baby_alert", 8, 8, True)
    generate_animation_json("dancing", "spark_baby_dancing", 12, 10, True)
    generate_animation_json("sparkle_fx", "spark_baby_sparkle_fx", 8, 12, False)
    generate_avatar_forms_json()
    
    # Sound effects (short tones)
    generate_wav("sfx_sparkle", 1200, 0.35, 0.25)
    generate_wav("sfx_pop", 800, 0.15, 0.4)
    generate_wav("sfx_sleep", 220, 0.6, 0.2)
    generate_wav("sfx_wake", 660, 0.3, 0.3)
    generate_wav("sfx_happy_chime", 880, 0.5, 0.25)
    generate_wav("sfx_error_soft", 300, 0.25, 0.2)
    generate_wav("sfx_form_unlock", 1400, 0.7, 0.3)
    
    print("\n=== Asset generation complete ===")
    print(f"PNG files in: {DRAWABLE_DIR}")
    print(f"WAV + JSON in: {RAW_DIR}")