# Spark Baby Pixel Overlay

**Spark Baby** is a cute pixel-art AI companion that floats as a passive overlay on your Android screen — always there, reacting to your world with moods, animations, voice commands, and a safe "Teach & Grow" memory system.

## Features

- 🧚 Floating pixel companion (small passive 96dp overlay, expands on tap)
- 🎨 10+ moods with smooth sprite animations (Idle, Happy, Curious, Thinking, Listening, Sleepy, Alert, Dancing, Proud, Confused, Glitchy)
- 🖐️ Drag to move, edge snapping, idle wandering behavior
- 🗣️ Voice commands via SpeechRecognizer (push-to-listen)
- 🤖 Pluggable AI: Local offline mode + OpenAI + Generic HTTP (user keys only, no hardcoded secrets)
- 🧠 Room database: memories, lessons, upgrades, forms, conversations
- 🛡️ Safe Teach & Grow system with prompt safety filters and upgrade risk classification
- 🌙 Dark neon pixel-art UI theme (purple/cyan/magenta)
- 📦 GitHub Actions builds debug APK automatically

## Tech Stack

- Kotlin + Jetpack Compose
- Room + KSP
- WindowManager TYPE_APPLICATION_OVERLAY + ForegroundService (specialUse)
- Android SpeechRecognizer + TextToSpeech
- Minimum SDK 26, Target 35, Java 17

## Getting Started (for development)

### Prerequisites
- Android Studio Hedgehog+ or newer
- JDK 17+
- Android SDK (API 35)

### Build

```bash
./gradlew clean assembleDebug
```

APK will be at `app/build/outputs/apk/debug/app-debug.apk`

### Run on device

1. Enable "Display over other apps" for Spark Baby
2. Grant notification permission
3. Grant microphone for voice commands (optional but recommended)
4. Tap the floating baby to expand controls
5. Long-press + drag to reposition
6. Use voice button or type commands in chat

## Commands (voice or text)

- "come here", "go away", "hide", "sleep", "wake up"
- "dance", "listen", "stop listening"
- "be happy", "be curious", "be quiet"
- "open chat", "close chat", "teach mode", "code mode"
- "change form"
- "remember that [fact]", "forget [thing]", "what did I teach you?"
- "show memories", "clear memory"

## Safety First

- All AI prompts filtered for risky content
- Code snippets from AI are classified (safe / review / blocked)
- No auto-execution of generated code
- User controls all API keys via secure keystore
- Privacy modes: local-only, balanced, full cloud

## Project Structure

See the full source layout in the repo. Key packages:
- `overlay/` — Floating service + custom PixelCompanionView
- `avatar/` — Mood, Behavior, Sprite animation engine
- `commands/` — Local command parser & dispatcher
- `ai/` — Pluggable providers (Local / OpenAI placeholder / Generic HTTP)
- `voice/` — SpeechRecognition + TTS controllers
- `data/` — Room entities + DAOs (6 tables)
- `safety/` — Prompt filter, upgrade checker, code classifier
- `ui/` — Compose screens + pixel theme components
- `security/` — ApiKeyManager + PrivacyMode

## Asset Generation

Run `python3 tools/generate_pixel_assets.py` to (re)generate all sprite sheets, animation JSONs and SFX WAVs.

## GitHub Actions

Pushes to `main` automatically build the debug APK via `.github/workflows/android-debug.yml` and upload it as artifact.

## License

Apache 2.0 (wrapper scripts) + custom for Spark Baby assets and code.

Made with ❤️ for curious minds and pixel lovers.
