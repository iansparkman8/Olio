#!/bin/bash
# Helper to commit and push (run after local setup)
git add .
git commit -m "feat: Spark Baby Pixel Overlay v0.3.0 - complete GitHub-ready build"
git push -u origin main
echo "Pushed. GitHub Actions will build the debug APK."
