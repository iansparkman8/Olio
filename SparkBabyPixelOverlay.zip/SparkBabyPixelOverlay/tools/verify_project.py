#!/usr/bin/env python3
"""
Spark Baby Pixel Overlay - Project Verifier
Checks that all required files exist and are non-empty.
Exits non-zero on any failure with a clear report.
"""

import os
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

REQUIRED_FILES = [
    # Gradle wrapper
    "gradlew",
    "gradlew.bat",
    "gradle/wrapper/gradle-wrapper.jar",
    "gradle/wrapper/gradle-wrapper.properties",
    
    # Core project
    "settings.gradle.kts",
    "build.gradle.kts",
    "app/build.gradle.kts",
    "app/src/main/AndroidManifest.xml",
    ".github/workflows/android-debug.yml",
    "app/src/main/res/xml/backup_rules.xml",
    "app/src/main/res/xml/data_extraction_rules.xml",
    
    # Source - main files (we will create all, but verify key ones here; full list in prompt)
    "app/src/main/java/com/sparkbaby/pixel/MainActivity.kt",
    "app/src/main/java/com/sparkbaby/pixel/SparkBabyApplication.kt",
    "app/src/main/java/com/sparkbaby/pixel/overlay/SparkOverlayService.kt",
    "app/src/main/java/com/sparkbaby/pixel/overlay/PixelCompanionView.kt",
    
    # Data layer
    "app/src/main/java/com/sparkbaby/pixel/data/SparkDatabase.kt",
    "app/src/main/java/com/sparkbaby/pixel/data/MemoryEntity.kt",
    
    # AI
    "app/src/main/java/com/sparkbaby/pixel/ai/AiProvider.kt",
    "app/src/main/java/com/sparkbaby/pixel/ai/LocalAiProvider.kt",
    
    # Safety
    "app/src/main/java/com/sparkbaby/pixel/safety/PromptSafetyFilter.kt",
    
    # UI
    "app/src/main/java/com/sparkbaby/pixel/ui/SparkBabyApp.kt",
    "app/src/main/java/com/sparkbaby/pixel/ui/theme/Theme.kt",
]

# All sprite / asset files that must exist and be > 100 bytes
ASSET_FILES = [
    "app/src/main/res/drawable-nodpi/spark_baby_idle.png",
    "app/src/main/res/drawable-nodpi/spark_baby_blink.png",
    "app/src/main/res/drawable-nodpi/spark_baby_happy.png",
    "app/src/main/res/drawable-nodpi/spark_baby_curious.png",
    "app/src/main/res/drawable-nodpi/spark_baby_thinking.png",
    "app/src/main/res/drawable-nodpi/spark_baby_listening.png",
    "app/src/main/res/drawable-nodpi/spark_baby_sleepy.png",
    "app/src/main/res/drawable-nodpi/spark_baby_alert.png",
    "app/src/main/res/drawable-nodpi/spark_baby_dancing.png",
    "app/src/main/res/drawable-nodpi/spark_baby_sparkle_fx.png",
    "app/src/main/res/drawable-nodpi/spark_baby_shadow.png",
    "app/src/main/res/drawable-nodpi/form_baby_sprite_idle.png",
    "app/src/main/res/drawable-nodpi/form_fairy_sprite_idle.png",
    "app/src/main/res/drawable-nodpi/form_cyber_fairy_idle.png",
    "app/src/main/res/drawable-nodpi/form_firefly_idle.png",
    "app/src/main/res/drawable-nodpi/form_pixel_angel_idle.png",
    "app/src/main/res/drawable-nodpi/form_glitch_fairy_idle.png",
    "app/src/main/res/drawable-nodpi/ui_pixel_panel_9patch.png",
    "app/src/main/res/drawable-nodpi/ui_pixel_button_9patch.png",
    "app/src/main/res/drawable-nodpi/ui_pixel_bubble_tail.png",
    "app/src/main/res/drawable-nodpi/ui_pixel_glow_ring.png",
    "app/src/main/res/drawable-nodpi/ui_pixel_command_cursor.png",
    
    # Raw JSON + WAV
    "app/src/main/res/raw/anim_idle.json",
    "app/src/main/res/raw/anim_blink.json",
    "app/src/main/res/raw/anim_happy.json",
    "app/src/main/res/raw/anim_curious.json",
    "app/src/main/res/raw/anim_thinking.json",
    "app/src/main/res/raw/anim_listening.json",
    "app/src/main/res/raw/anim_sleepy.json",
    "app/src/main/res/raw/anim_alert.json",
    "app/src/main/res/raw/anim_dancing.json",
    "app/src/main/res/raw/anim_sparkle_fx.json",
    "app/src/main/res/raw/avatar_forms.json",
    "app/src/main/res/raw/sfx_sparkle.wav",
    "app/src/main/res/raw/sfx_pop.wav",
    "app/src/main/res/raw/sfx_sleep.wav",
    "app/src/main/res/raw/sfx_wake.wav",
    "app/src/main/res/raw/sfx_happy_chime.wav",
    "app/src/main/res/raw/sfx_error_soft.wav",
    "app/src/main/res/raw/sfx_form_unlock.wav",
]

FORBIDDEN_STRINGS = ["sk-", "Bearer ", "api_key = ", "apiKey="]

def check_file(path, min_size=1):
    full = os.path.join(BASE, path)
    if not os.path.isfile(full):
        return False, f"MISSING: {path}"
    size = os.path.getsize(full)
    if size < min_size:
        return False, f"EMPTY or too small ({size} bytes): {path}"
    return True, f"OK ({size} bytes): {path}"

def check_no_forbidden(path):
    full = os.path.join(BASE, path)
    if not os.path.isfile(full):
        return True  # missing is handled elsewhere
    try:
        with open(full, "r", errors="ignore") as f:
            content = f.read().lower()
            for bad in FORBIDDEN_STRINGS:
                if bad.lower() in content:
                    return False, f"FORBIDDEN string '{bad}' found in {path}"
    except Exception:
        pass
    return True, ""

def main():
    print("=== Spark Baby Project Verification ===\n")
    
    all_ok = True
    report = []
    
    # 1. Core files
    print("Checking core & wrapper files...")
    for f in REQUIRED_FILES:
        ok, msg = check_file(f, min_size=20 if "gradle-wrapper.jar" not in f else 1)
        print("  " + msg)
        if not ok:
            all_ok = False
        report.append(msg)
    
    # 2. Assets
    print("\nChecking generated assets (PNG/JSON/WAV)...")
    for f in ASSET_FILES:
        ok, msg = check_file(f, min_size=50)  # PNGs/JSONs/WAVs should be >50 bytes
        print("  " + msg)
        if not ok:
            all_ok = False
        report.append(msg)
    
    # 3. Forbidden strings check (on key source files)
    print("\nChecking for hardcoded secrets (forbidden patterns)...")
    key_files = [f for f in REQUIRED_FILES if f.endswith(".kt") or f.endswith(".xml") or f.endswith(".kts")]
    for f in key_files[:8]:  # sample some
        ok, msg = check_no_forbidden(f)
        if not ok:
            print("  " + msg)
            all_ok = False
            report.append(msg)
        else:
            print(f"  No forbidden strings: {f}")
    
    # 4. Manifest check - no AccessibilityService
    manifest_path = os.path.join(BASE, "app/src/main/AndroidManifest.xml")
    if os.path.isfile(manifest_path):
        with open(manifest_path) as f:
            manifest = f.read()
            # Only flag if "AccessibilityService" appears outside of comments
            non_comment_lines = [line for line in manifest.splitlines() if not line.strip().startswith("<!--")]
            if any("AccessibilityService" in line for line in non_comment_lines):
                print("  FAIL: AndroidManifest.xml contains AccessibilityService (forbidden)")
                all_ok = False
            else:
                print("  PASS: No AccessibilityService in manifest")
    
    print("\n" + "="*50)
    if all_ok:
        print("✅ VERIFICATION PASSED - All files present and valid.")
        sys.exit(0)
    else:
        print("❌ VERIFICATION FAILED - See missing/empty files above.")
        sys.exit(1)

if __name__ == "__main__":
    main()
