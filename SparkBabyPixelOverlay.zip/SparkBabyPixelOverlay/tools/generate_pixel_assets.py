#!/usr/bin/env python3
"""
Spark Baby Pixel Overlay - Asset Generator
Generates all required PNG sprite sheets, JSON animation defs, and tiny WAV SFX.
Run with: python3 tools/generate_pixel_assets.py
"""

import os
import json
import math
import struct
import wave
from PIL import Image, ImageDraw, ImageFilter

# Output paths
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DRAWABLE_DIR = os.path.join(BASE_DIR, "app", "src", "main", "res", "drawable-nodpi")
RAW_DIR = os.path.join(BASE_DIR, "app", "src", "main", "res", "raw")

os.makedirs(DRAWABLE_DIR, exist_ok=True)
os.makedirs(RAW_DIR, exist_ok=True)

# Color palette - neon pixel cute
NEON_PURPLE = (180, 80, 255)
NEON_CYAN = (80, 220, 255)
NEON_MAGENTA = (255, 80, 200)
NEON_YELLOW = (255, 230, 80)
NEON_GREEN = (80, 255, 150)
WHITE = (255, 255, 255)
BLACK = (20, 10, 30)
DARK_BG = (15, 10, 25)
TRANSPARENT = (0, 0, 0, 0)

def create_pixel_sprite(size=32, color=NEON_PURPLE, accent=NEON_CYAN, mood="idle"):
    """Create a simple cute pixel baby sprite 32x32 with transparent bg"""
    img = Image.new('RGBA', (size, size), TRANSPARENT)
    draw = ImageDraw.Draw(img)
    
    # Body (round pixel blob)
    body_color = color
    if mood == "happy":
        body_color = NEON_MAGENTA
    elif mood == "sleepy":
        body_color = (120, 100, 180)
    elif mood == "alert":
        body_color = NEON_YELLOW
    elif mood == "glitchy":
        body_color = (255, 100, 100)
    
    # Head/body circle-ish (pixel style)
    draw.ellipse([6, 4, 26, 24], fill=body_color, outline=BLACK)
    
    # Eyes
    eye_y = 10
    if mood in ["sleepy", "thinking"]:
        draw.line([(9, eye_y+2), (12, eye_y+2)], fill=BLACK, width=2)
        draw.line([(19, eye_y+2), (22, eye_y+2)], fill=BLACK, width=2)
    elif mood == "happy":
        draw.arc([8, eye_y-1, 13, eye_y+4], 0, 180, fill=BLACK, width=2)
        draw.arc([18, eye_y-1, 23, eye_y+4], 0, 180, fill=BLACK, width=2)
    else:
        draw.ellipse([8, eye_y, 13, eye_y+5], fill=BLACK)
        draw.ellipse([18, eye_y, 23, eye_y+5], fill=BLACK)
        # Eye shine
        draw.point((10, eye_y+1), fill=WHITE)
        draw.point((20, eye_y+1), fill=WHITE)
    
    # Mouth / expression
    mouth_y = 17
    if mood == "happy":
        draw.arc([11, mouth_y-2, 20, mouth_y+4], 0, 180, fill=BLACK, width=2)
    elif mood == "curious":
        draw.ellipse([13, mouth_y, 18, mouth_y+3], outline=BLACK, width=1)
    elif mood == "thinking":
        draw.line([(12, mouth_y+1), (19, mouth_y+1)], fill=BLACK, width=2)
    elif mood == "glitchy":
        draw.line([(10, mouth_y), (14, mouth_y+2)], fill=BLACK, width=1)
        draw.line([(16, mouth_y+1), (21, mouth_y-1)], fill=BLACK, width=1)
    else:
        draw.line([(12, mouth_y+1), (19, mouth_y+1)], fill=BLACK, width=1)
    
    # Sparkle / antenna for some moods
    if mood in ["idle", "alert", "curious", "happy"]:
        draw.line([(16, 4), (16, 0)], fill=NEON_YELLOW, width=2)
        draw.ellipse([14, 0, 18, 4], fill=NEON_YELLOW)
    
    # Blush for happy
    if mood == "happy":
        draw.ellipse([5, 14, 9, 17], fill=(255, 150, 180, 180))
        draw.ellipse([22, 14, 26, 17], fill=(255, 150, 180, 180))
    
    # Glitch lines
    if mood == "glitchy":
        for i in range(3):
            y = 6 + i*6
            draw.line([(2, y), (30, y+1)], fill=(255, 255, 255, 120), width=1)
    
    return img

def create_animation_sheet(frames=8, size=32, mood="idle"):
    """Create horizontal sprite sheet  (frames * size) x size """
    sheet_width = frames * size
    sheet = Image.new('RGBA', (sheet_width, size), TRANSPARENT)
    
    colors = [NEON_PURPLE, NEON_MAGENTA, NEON_CYAN]
    
    for i in range(frames):
        # Slight variation per frame for animation feel
        color = colors[i % 3]
        if mood == "dancing":
            color = NEON_YELLOW if i % 2 == 0 else NEON_MAGENTA
        sprite = create_pixel_sprite(size, color=color, mood=mood)
        
        # Add subtle bob / sway for animation
        offset_x = 0
        offset_y = 0
        if mood == "dancing":
            offset_y = 2 if i % 2 == 0 else -2
            offset_x = 1 if (i // 2) % 2 == 0 else -1
        elif mood == "idle":
            offset_y = 1 if i % 4 == 0 else 0
        elif mood == "glitchy":
            offset_x = (i % 3) - 1
        
        x = i * size + offset_x
        y = offset_y
        sheet.paste(sprite, (x, y), sprite)
    
    return sheet

def generate_all_sprites():
    print("Generating pixel sprite sheets...")
    
    moods = [
        ("idle", 8),
        ("blink", 4),
        ("happy", 8),
        ("curious", 6),
        ("thinking", 8),
        ("listening", 6),
        ("sleepy", 8),
        ("alert", 6),
        ("dancing", 12),  # longer for dance
        ("sparkle_fx", 8),
    ]
    
    for mood, frame_count in moods:
        sheet = create_animation_sheet(frames=frame_count, mood=mood)
        filename = f"spark_baby_{mood}.png"
        path = os.path.join(DRAWABLE_DIR, filename)
        sheet.save(path, "PNG")
        print(f"  Created {filename} ({frame_count} frames)")
    
    # Extra form sprites (different evolutions)
    forms = [
        "form_baby_sprite_idle",
        "form_fairy_sprite_idle",
        "form_cyber_fairy_idle",
        "form_firefly_idle",
        "form_pixel_angel_idle",
        "form_glitch_fairy_idle",
    ]
    for form in forms:
        img = create_pixel_sprite(32, color=NEON_CYAN if "cyber" in form else NEON_MAGENTA, mood="idle")
        # Add form-specific flair
        draw = ImageDraw.Draw(img)
        if "fairy" in form:
            draw.polygon([(2, 8), (6, 2), (10, 8)], fill=NEON_YELLOW)  # wing
            draw.polygon([(22, 8), (26, 2), (30, 8)], fill=NEON_YELLOW)
        elif "angel" in form:
            draw.arc([4, 2, 28, 12], 200, 340, fill=WHITE, width=2)
        path = os.path.join(DRAWABLE_DIR, f"{form}.png")
        img.save(path, "PNG")
        print(f"  Created {form}.png")
    
    # Shadow
    shadow = Image.new('RGBA', (32, 32), TRANSPARENT)
    draw = ImageDraw.Draw(shadow)
    draw.ellipse([4, 24, 28, 30], fill=(0, 0, 0, 80))
    shadow.save(os.path.join(DRAWABLE_DIR, "spark_baby_shadow.png"), "PNG")
    print("  Created spark_baby_shadow.png")
    
    # UI 9-patch style elements (simple)
    panel = Image.new('RGBA', (48, 48), TRANSPARENT)
    d = ImageDraw.Draw(panel)
    d.rectangle([2, 2, 45, 45], outline=NEON_PURPLE, width=3)
    d.rectangle([6, 6, 41, 41], fill=(30, 20, 50, 200))
    panel.save(os.path.join(DRAWABLE_DIR, "ui_pixel_panel_9patch.png"), "PNG")
    print("  Created ui_pixel_panel_9patch.png")
    
    button = Image.new('RGBA', (32, 32), TRANSPARENT)
    d = ImageDraw.Draw(button)
    d.rectangle([1, 1, 30, 30], fill=NEON_CYAN, outline=WHITE, width=2)
    button.save(os.path.join(DRAWABLE_DIR, "ui_pixel_button_9patch.png"), "PNG")
    print("  Created ui_pixel_button_9patch.png")
    
    # Bubble tail
    tail = Image.new('RGBA', (16, 16), TRANSPARENT)
    d = ImageDraw.Draw(tail)
    d.polygon([(0, 0), (16, 8), (0, 16)], fill=NEON_PURPLE)
    tail.save(os.path.join(DRAWABLE_DIR, "ui_pixel_bubble_tail.png"), "PNG")
    print("  Created ui_pixel_bubble_tail.png")
    
    # Glow ring
    glow = Image.new('RGBA', (64, 64), TRANSPARENT)
    d = ImageDraw.Draw(glow)
    d.ellipse([4, 4, 60, 60], outline=NEON_CYAN, width=4)
    glow.save(os.path.join(DRAWABLE_DIR, "ui_pixel_glow_ring.png"), "PNG")
    print("  Created ui_pixel_glow_ring.png")
    
    # Command cursor
    cursor = Image.new('RGBA', (16, 16), TRANSPARENT)
    d = ImageDraw.Draw(cursor)
    d.polygon([(2, 2), (14, 8), (2, 14)], fill=NEON_YELLOW)
    cursor.save(os.path.join(DRAWABLE_DIR, "ui_pixel_command_cursor.png"), "PNG")
    print("  Created ui_pixel_command_cursor.png")

def generate_animation_json():
    print("Generating animation JSONs...")
    
    anims = {
        "anim_idle.json": {"frames": 8, "fps": 4, "loop": True, "pingpong": False},
        "anim_blink.json": {"frames": 4, "fps": 8, "loop": True, "pingpong": True},
        "anim_happy.json": {"frames": 8, "fps": 6, "loop": True, "pingpong": False},
        "anim_curious.json": {"frames": 6, "fps": 5, "loop": True, "pingpong": False},
        "anim_thinking.json": {"frames": 8, "fps": 3, "loop": True, "pingpong": True},
        "anim_listening.json": {"frames": 6, "fps": 7, "loop": True, "pingpong": False},
        "anim_sleepy.json": {"frames": 8, "fps": 2, "loop": True, "pingpong": False},
        "anim_alert.json": {"frames": 6, "fps": 8, "loop": True, "pingpong": True},
        "anim_dancing.json": {"frames": 12, "fps": 10, "loop": True, "pingpong": False},
        "anim_sparkle_fx.json": {"frames": 8, "fps": 12, "loop": False, "pingpong": False},
    }
    
    for name, data in anims.items():
        path = os.path.join(RAW_DIR, name)
        with open(path, "w") as f:
            json.dump(data, f, indent=2)
        print(f"  Created {name}")
    
    # Avatar forms catalog
    forms = {
        "forms": [
            {"id": "baby", "name": "Baby Spark", "sprite": "form_baby_sprite_idle", "unlock_level": 1},
            {"id": "fairy", "name": "Pixel Fairy", "sprite": "form_fairy_sprite_idle", "unlock_level": 3},
            {"id": "cyber_fairy", "name": "Cyber Fairy", "sprite": "form_cyber_fairy_idle", "unlock_level": 5},
            {"id": "firefly", "name": "Neon Firefly", "sprite": "form_firefly_idle", "unlock_level": 7},
            {"id": "angel", "name": "Pixel Angel", "sprite": "form_pixel_angel_idle", "unlock_level": 10},
            {"id": "glitch_fairy", "name": "Glitch Fairy", "sprite": "form_glitch_fairy_idle", "unlock_level": 12},
        ]
    }
    with open(os.path.join(RAW_DIR, "avatar_forms.json"), "w") as f:
        json.dump(forms, f, indent=2)
    print("  Created avatar_forms.json")

def generate_wav_tones():
    print("Generating tiny SFX WAVs...")
    
    def make_tone(filename, freq=440, duration_ms=150, volume=0.6, wave_type="sine"):
        path = os.path.join(RAW_DIR, filename)
        framerate = 44100
        nframes = int(framerate * duration_ms / 1000)
        wav_file = wave.open(path, 'w')
        wav_file.setparams((1, 2, framerate, nframes, 'NONE', 'not compressed'))
        
        for i in range(nframes):
            t = float(i) / framerate
            if wave_type == "sine":
                val = int(volume * 32767 * math.sin(2 * math.pi * freq * t))
            elif wave_type == "square":
                val = int(volume * 32767 * (1 if math.sin(2 * math.pi * freq * t) > 0 else -1))
            else:
                val = int(volume * 32767 * math.sin(2 * math.pi * freq * t))
            
            # Simple envelope
            env = 1.0 - (i / nframes)
            val = int(val * env)
            wav_file.writeframes(struct.pack('<h', val))
        wav_file.close()
        print(f"  Created {filename} ({duration_ms}ms @ {freq}Hz)")
    
    make_tone("sfx_sparkle.wav", freq=880, duration_ms=200, wave_type="sine")
    make_tone("sfx_pop.wav", freq=660, duration_ms=80, wave_type="square")
    make_tone("sfx_sleep.wav", freq=220, duration_ms=400, wave_type="sine")
    make_tone("sfx_wake.wav", freq=550, duration_ms=120, wave_type="sine")
    make_tone("sfx_happy_chime.wav", freq=990, duration_ms=180, wave_type="sine")
    make_tone("sfx_error_soft.wav", freq=180, duration_ms=250, wave_type="square")
    make_tone("sfx_form_unlock.wav", freq=1200, duration_ms=300, wave_type="sine")

if __name__ == "__main__":
    print("=== Spark Baby Asset Generator ===")
    generate_all_sprites()
    generate_animation_json()
    generate_wav_tones()
    print("\n✅ All assets generated successfully in drawable-nodpi/ and raw/")
