# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# Keep Room entities and DAOs
-keep class com.sparkbaby.pixel.data.** { *; }
-keep interface com.sparkbaby.pixel.data.** { *; }

# Keep Compose and navigation
-keep class androidx.compose.** { *; }
-keep class androidx.navigation.** { *; }
