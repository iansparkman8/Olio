package com.sparkbaby.pixel.util

import java.text.SimpleDateFormat
import java.util.*

object TimeUtils {
    fun formatTimestamp(ts: Long): String {
        return SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault()).format(Date(ts))
    }
}
