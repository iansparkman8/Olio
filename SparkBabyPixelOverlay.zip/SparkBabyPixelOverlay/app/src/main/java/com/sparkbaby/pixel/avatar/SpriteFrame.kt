package com.sparkbaby.pixel.avatar

import android.graphics.Bitmap

data class SpriteFrame(
    val bitmap: Bitmap,
    val durationMs: Long = 120
)
