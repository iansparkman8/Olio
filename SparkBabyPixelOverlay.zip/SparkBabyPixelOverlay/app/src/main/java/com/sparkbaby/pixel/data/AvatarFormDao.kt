package com.sparkbaby.pixel.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AvatarFormDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(form: AvatarFormEntity)

    @Query("SELECT * FROM avatar_forms")
    fun getAll(): Flow<List<AvatarFormEntity>>
}
