package com.sparkbaby.pixel.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object SecureKeyStore {

    private const val PREFS_NAME = "spark_baby_secure_prefs"

    private fun getPrefs(context: Context): SharedPreferences {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        return EncryptedSharedPreferences.create(
            context,
            PREFS_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun saveKey(context: Context, keyName: String, value: String) {
        getPrefs(context).edit().putString(keyName, value).apply()
    }

    fun getKey(context: Context, keyName: String): String? {
        return getPrefs(context).getString(keyName, null)
    }

    fun clearKey(context: Context, keyName: String) {
        getPrefs(context).edit().remove(keyName).apply()
    }
}
