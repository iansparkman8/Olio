package com.sparkbaby.pixel.overlay

import android.content.Context
import android.provider.Settings

object OverlayPermissionHelper {
    fun hasOverlayPermission(context: Context): Boolean {
        return Settings.canDrawOverlays(context)
    }
}
