package com.sparkbaby.pixel.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.sparkbaby.pixel.R

@Composable
fun SparkPreview(modifier: Modifier = Modifier) {
    // Uses one of the generated assets
    Image(
        painter = painterResource(id = R.drawable.spark_baby_idle),
        contentDescription = "Spark Baby preview",
        modifier = modifier.size(160.dp)
    )
}
