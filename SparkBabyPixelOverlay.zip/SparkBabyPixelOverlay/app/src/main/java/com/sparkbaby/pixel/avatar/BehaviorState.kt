package com.sparkbaby.pixel.avatar

enum class BehaviorState {
    IDLE_WANDERING,
    FOLLOWING_USER,
    RESTING,
    REACTING_TO_COMMAND,
    LEARNING
}
