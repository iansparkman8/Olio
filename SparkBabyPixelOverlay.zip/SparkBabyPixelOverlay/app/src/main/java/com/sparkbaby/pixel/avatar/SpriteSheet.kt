package com.sparkbaby.pixel.avatar

import android.graphics.Bitmap
import android.graphics.Rect

class SpriteSheet(
    private val sheetBitmap: Bitmap,
    private val frameCount: Int,
    private val frameWidth: Int = 32
) {
    private val frameHeight: Int = sheetBitmap.height
    private val frames = mutableListOf<Bitmap>()

    init {
        val actualFrameW = sheetBitmap.width / frameCount
        for (i in 0 until frameCount) {
            val x = i * actualFrameW
            val frame = Bitmap.createBitmap(
                sheetBitmap,
                x, 0,
                actualFrameW.coerceAtMost(frameWidth),
                frameHeight.coerceAtMost(32)
            )
            frames.add(frame)
        }
    }

    fun getFrame(index: Int): Bitmap {
        return frames.getOrNull(index % frames.size) ?: frames.first()
    }

    fun getFrameCount(): Int = frames.size
}
