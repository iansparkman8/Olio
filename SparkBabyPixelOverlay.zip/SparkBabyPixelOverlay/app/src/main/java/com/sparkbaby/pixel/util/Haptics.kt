package com.sparkbaby.pixel.util

import android.content.Context
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.content.getSystemService

object Haptics {
    fun gentleTap(context: Context) {
        val vibrator = context.getSystemService<Vibrator>()
        vibrator?.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
    }
}
