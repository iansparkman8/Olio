package com.sparkbaby.pixel.ai

import com.sparkbaby.pixel.data.MemoryEntity

object PromptBuilder {

    fun build(systemPrompt: String, memories: List<MemoryEntity>, userMessage: String): String {
        val memoryBlock = if (memories.isNotEmpty()) {
            memories.joinToString("\n") { "- ${it.content}" }
        } else {
            "No memories yet."
        }
        return """
            $systemPrompt
            
            Important memories / lessons from user:
            $memoryBlock
            
            User: $userMessage
            Spark Baby:
        """.trimIndent()
    }
}
