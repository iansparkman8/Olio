package com.sparkbaby.pixel.ai

data class AiReply(
    val text: String,
    val confidence: Float = 0.8f,
    val fromProvider: String,
    val wasFiltered: Boolean = false
)
