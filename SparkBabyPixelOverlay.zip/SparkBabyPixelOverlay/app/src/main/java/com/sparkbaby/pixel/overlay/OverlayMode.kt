package com.sparkbaby.pixel.overlay

enum class OverlayMode {
    COLLAPSED,   // Small 96dp floating baby
    EXPANDED,    // Larger control bubble ~320x420
    HIDDEN
}
