package com.sparkbaby.pixel.commands

enum class CommandAction {
    COME_HERE,
    GO_AWAY,
    HIDE,
    SLEEP,
    WAKE_UP,
    DANCE,
    LISTEN,
    STOP_LISTENING,
    BE_HAPPY,
    BE_CURIOUS,
    BE_QUIET,
    OPEN_CHAT,
    CLOSE_CHAT,
    TEACH_MODE,
    CODE_MODE,
    CHANGE_FORM,
    REMEMBER,
    FORGET,
    WHAT_DID_I_TEACH_YOU,
    SHOW_MEMORIES,
    CLEAR_MEMORY,
    UNKNOWN
}
