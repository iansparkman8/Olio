package com.sparkbaby.pixel.commands

object CommandParser {

    fun parse(input: String): CommandAction {
        val lower = input.lowercase().trim()
        return when {
            lower.contains("come here") || lower.contains("come to me") -> CommandAction.COME_HERE
            lower.contains("go away") || lower.contains("leave") -> CommandAction.GO_AWAY
            lower.contains("hide") -> CommandAction.HIDE
            lower.contains("sleep") -> CommandAction.SLEEP
            lower.contains("wake up") || lower.contains("wake") -> CommandAction.WAKE_UP
            lower.contains("dance") -> CommandAction.DANCE
            lower.contains("listen") && !lower.contains("stop") -> CommandAction.LISTEN
            lower.contains("stop listening") -> CommandAction.STOP_LISTENING
            lower.contains("be happy") -> CommandAction.BE_HAPPY
            lower.contains("be curious") -> CommandAction.BE_CURIOUS
            lower.contains("be quiet") -> CommandAction.BE_QUIET
            lower.contains("open chat") -> CommandAction.OPEN_CHAT
            lower.contains("close chat") -> CommandAction.CLOSE_CHAT
            lower.contains("teach mode") -> CommandAction.TEACH_MODE
            lower.contains("code mode") -> CommandAction.CODE_MODE
            lower.contains("change form") || lower.contains("evolve") -> CommandAction.CHANGE_FORM
            lower.startsWith("remember that") || lower.startsWith("remember") -> CommandAction.REMEMBER
            lower.contains("forget") -> CommandAction.FORGET
            lower.contains("what did i teach") -> CommandAction.WHAT_DID_I_TEACH_YOU
            lower.contains("show memories") || lower.contains("memories") -> CommandAction.SHOW_MEMORIES
            lower.contains("clear memory") -> CommandAction.CLEAR_MEMORY
            else -> CommandAction.UNKNOWN
        }
    }
}
