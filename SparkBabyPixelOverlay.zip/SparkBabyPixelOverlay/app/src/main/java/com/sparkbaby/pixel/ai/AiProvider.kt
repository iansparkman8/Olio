package com.sparkbaby.pixel.ai

interface AiProvider {
    suspend fun getReply(prompt: String, context: List<String> = emptyList()): AiReply
    fun getProviderName(): String
}
