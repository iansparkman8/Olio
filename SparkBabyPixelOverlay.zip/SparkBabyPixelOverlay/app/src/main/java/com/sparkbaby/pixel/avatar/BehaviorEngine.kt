package com.sparkbaby.pixel.avatar

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class BehaviorEngine {
    private val _currentBehavior = MutableStateFlow(BehaviorState.IDLE_WANDERING)
    val currentBehavior: StateFlow<BehaviorState> = _currentBehavior

    fun onIntent(intent: AvatarIntent) {
        when (intent) {
            is AvatarIntent.Dance -> _currentBehavior.value = BehaviorState.REACTING_TO_COMMAND
            is AvatarIntent.Remember -> _currentBehavior.value = BehaviorState.LEARNING
            else -> {}
        }
    }
}
