package com.sparkbaby.pixel.commands

import com.sparkbaby.pixel.avatar.MoodState
import com.sparkbaby.pixel.overlay.PixelCompanionView
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

class ActionDispatcher(
    private val companionView: PixelCompanionView? = null
) {
    private val _events = MutableSharedFlow<CommandAction>(extraBufferCapacity = 10)
    val events = _events.asSharedFlow()

    suspend fun dispatch(action: CommandAction, payload: String? = null) {
        when (action) {
            CommandAction.BE_HAPPY -> companionView?.setMood(MoodState.HAPPY)
            CommandAction.BE_CURIOUS -> companionView?.setMood(MoodState.CURIOUS)
            CommandAction.DANCE -> companionView?.setMood(MoodState.DANCING)
            CommandAction.SLEEP -> companionView?.setMood(MoodState.SLEEPY)
            CommandAction.WAKE_UP -> companionView?.setMood(MoodState.ALERT)
            else -> {}
        }
        _events.emit(action)
    }
}
