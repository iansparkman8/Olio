package com.sparkbaby.pixel.safety

enum class RiskLevel {
    SAFE,
    REVIEW_NEEDED,
    BLOCKED
}
