package com.sparkbaby.pixel.ai

import com.sparkbaby.pixel.security.ApiKeyManager

class OpenAiProvider(
    private val apiKeyManager: ApiKeyManager
) : AiProvider {

    override suspend fun getReply(prompt: String, context: List<String>): AiReply {
        val key = apiKeyManager.getOpenAiKey()
        if (key.isNullOrBlank()) {
            return AiReply(
                text = "OpenAI key not set. Please add it in Settings.",
                fromProvider = "OpenAI",
                wasFiltered = true
            )
        }
        // TODO: Real HTTP call to OpenAI with safety filter first
        return AiReply(
            text = "[OpenAI placeholder] I would reply thoughtfully here after checking safety filters.",
            fromProvider = "OpenAI",
            confidence = 0.9f
        )
    }

    override fun getProviderName() = "OpenAI"
}
