package com.sparkbaby.pixel.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.sparkbaby.pixel.ui.components.PixelButton
import com.sparkbaby.pixel.ui.navigation.AppNavHost
import com.sparkbaby.pixel.ui.navigation.Routes

@Composable
fun SparkBabyApp(
    onStartOverlay: () -> Unit,
    onStopOverlay: () -> Unit,
    onRequestOverlayPermission: () -> Unit
) {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                NavigationBarItem(
                    selected = false,
                    onClick = { navController.navigate(Routes.HOME) },
                    icon = { Text("🏠") },
                    label = { Text("Home") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { navController.navigate(Routes.CONTROL_PANEL) },
                    icon = { Text("🎮") },
                    label = { Text("Control") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { navController.navigate(Routes.TEACH_GROW) },
                    icon = { Text("🌱") },
                    label = { Text("Teach") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { navController.navigate(Routes.SETTINGS) },
                    icon = { Text("⚙️") },
                    label = { Text("Settings") }
                )
            }
        }
    ) { padding ->
        AppNavHost(
            navController = navController,
            startOverlay = onStartOverlay,
            stopOverlay = onStopOverlay
        )
    }
}
