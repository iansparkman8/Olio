package com.sparkbaby.pixel.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        MemoryEntity::class,
        LessonEntity::class,
        CommandEntity::class,
        UpgradeEntity::class,
        AvatarFormEntity::class,
        ConversationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SparkDatabase : RoomDatabase() {

    abstract fun memoryDao(): MemoryDao
    abstract fun lessonDao(): LessonDao
    abstract fun commandDao(): CommandDao
    abstract fun upgradeDao(): UpgradeDao
    abstract fun avatarFormDao(): AvatarFormDao
    abstract fun conversationDao(): ConversationDao

    companion object {
        @Volatile
        private var INSTANCE: SparkDatabase? = null

        fun getDatabase(context: Context): SparkDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SparkDatabase::class.java,
                    "spark_baby_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
