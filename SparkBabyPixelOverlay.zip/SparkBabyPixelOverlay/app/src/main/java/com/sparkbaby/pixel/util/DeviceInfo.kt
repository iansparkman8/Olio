package com.sparkbaby.pixel.util

import android.os.Build

object DeviceInfo {
    val sdkInt: Int get() = Build.VERSION.SDK_INT
    val isAndroid14Plus: Boolean get() = sdkInt >= 34
}
