package com.sparkbaby.pixel.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface UpgradeDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(upgrade: UpgradeEntity)

    @Query("SELECT * FROM upgrades")
    fun getAll(): Flow<List<UpgradeEntity>>
}
