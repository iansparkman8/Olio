package com.sparkbaby.pixel.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "upgrades")
data class UpgradeEntity(
    @PrimaryKey val upgradeId: String,
    val name: String,
    val level: Int = 0,
    val unlocked: Boolean = false,
    val unlockedAt: Long? = null
)
