package com.sparkbaby.pixel.commands

import com.sparkbaby.pixel.avatar.MoodState

object LocalCommandRegistry {

    val supportedCommands = listOf(
        "come here", "go away", "hide", "sleep", "wake up",
        "dance", "listen", "stop listening",
        "be happy", "be curious", "be quiet",
        "open chat", "close chat", "teach mode", "code mode",
        "change form", "remember that...", "forget...", 
        "what did I teach you?", "show memories", "clear memory"
    )

    fun getResponseFor(action: CommandAction): String {
        return when (action) {
            CommandAction.DANCE -> "Yay! *sparkles and dances*"
            CommandAction.BE_HAPPY -> "Feeling happy now! ✨"
            CommandAction.SLEEP -> "Zzz... going to sleep mode"
            CommandAction.WAKE_UP -> "I'm awake! Hi again!"
            CommandAction.CHANGE_FORM -> "Which form would you like? (Baby / Fairy / Cyber...)"
            else -> "Got it! Doing that now."
        }
    }
}
