package com.sparkbaby.pixel.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.sparkbaby.pixel.security.PrivacyMode
import com.sparkbaby.pixel.ui.components.PixelButton

@Composable
fun SettingsScreen(navController: NavController) {
    var privacy by remember { mutableStateOf(PrivacyMode.BALANCED) }
    var openAiKey by remember { mutableStateOf("") }

    Column(Modifier.padding(16.dp)) {
        Text("Settings", style = MaterialTheme.typography.titleLarge)

        Spacer(Modifier.height(16.dp))
        Text("Privacy Mode")
        // Simple segmented control simulation
        Row {
            listOf(PrivacyMode.LOCAL_ONLY, PrivacyMode.BALANCED, PrivacyMode.FULL_CLOUD).forEach { mode ->
                PixelButton(
                    text = mode.name,
                    onClick = { privacy = mode },
                    variant = if (privacy == mode) "primary" else "ghost"
                )
            }
        }

        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = openAiKey,
            onValueChange = { openAiKey = it },
            label = { Text("OpenAI API Key (stored encrypted)") },
            modifier = Modifier.fillMaxWidth()
        )
        PixelButton("Save Key Securely", onClick = { /* save via ApiKeyManager */ })

        Spacer(Modifier.height(24.dp))
        Text("Safety: All prompts filtered • Code snippets classified • No auto-execution")
    }
}
