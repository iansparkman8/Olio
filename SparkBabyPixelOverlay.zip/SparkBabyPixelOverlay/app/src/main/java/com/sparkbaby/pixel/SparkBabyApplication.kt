package com.sparkbaby.pixel

import android.app.Application
import com.sparkbaby.pixel.data.SparkDatabase

class SparkBabyApplication : Application() {

    val database: SparkDatabase by lazy {
        SparkDatabase.getDatabase(this)
    }

    override fun onCreate() {
        super.onCreate()
        // Initialize any global singletons here if needed
    }
}
