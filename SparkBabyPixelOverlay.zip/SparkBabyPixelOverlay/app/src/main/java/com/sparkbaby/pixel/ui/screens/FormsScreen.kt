package com.sparkbaby.pixel.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.sparkbaby.pixel.ui.components.PixelButton

@Composable
fun FormsScreen(navController: NavController) {
    Column(Modifier.padding(16.dp)) {
        Text("Avatar Forms", style = MaterialTheme.typography.titleLarge)
        Text("Unlock new pixel forms as you teach & interact!")

        Spacer(Modifier.height(12.dp))
        Text("• Baby Spark (starting)")
        Text("• Pixel Fairy")
        Text("• Cyber Fairy")
        Text("• Neon Firefly")
        Text("• Pixel Angel")
        Text("• Glitch Fairy (secret)")

        Spacer(Modifier.height(16.dp))
        PixelButton("Back to Control", onClick = { navController.popBackStack() })
    }
}
