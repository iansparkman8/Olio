package com.sparkbaby.pixel.util

import android.util.Log

object Logger {
    private const val TAG = "SparkBaby"

    fun d(msg: String) = Log.d(TAG, msg)
    fun e(msg: String, t: Throwable? = null) = Log.e(TAG, msg, t)
}
