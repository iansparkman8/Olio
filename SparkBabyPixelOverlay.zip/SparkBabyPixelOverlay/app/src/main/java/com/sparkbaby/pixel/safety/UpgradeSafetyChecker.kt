package com.sparkbaby.pixel.safety

object UpgradeSafetyChecker {

    fun checkUpgrade(upgradeId: String, currentLevel: Int): RiskLevel {
        // Future: more sophisticated checks
        return if (upgradeId.contains("root") || currentLevel > 10) {
            RiskLevel.REVIEW_NEEDED
        } else {
            RiskLevel.SAFE
        }
    }
}
