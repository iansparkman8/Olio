package com.sparkbaby.pixel.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import com.sparkbaby.pixel.R

object OverlayNotification {

    const val CHANNEL_ID = "spark_baby_overlay_channel"
    const val NOTIFICATION_ID = 1001

    fun createNotification(context: Context): Notification {
        createNotificationChannel(context)

        return NotificationCompat.Builder(context, CHANNEL_ID)
            .setContentTitle(context.getString(R.string.overlay_notification_title))
            .setContentText(context.getString(R.string.overlay_notification_text))
            .setSmallIcon(R.drawable.ic_launcher) // TODO: replace with proper small icon
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Spark Baby Overlay",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps Spark Baby floating companion running"
                setShowBadge(false)
            }
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }
}
