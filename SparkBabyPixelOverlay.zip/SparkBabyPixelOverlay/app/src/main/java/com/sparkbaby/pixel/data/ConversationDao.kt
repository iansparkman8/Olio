package com.sparkbaby.pixel.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ConversationDao {
    @Insert
    suspend fun insert(msg: ConversationEntity)

    @Query("SELECT * FROM conversations ORDER BY timestamp ASC")
    fun getAll(): Flow<List<ConversationEntity>>

    @Query("DELETE FROM conversations")
    suspend fun clearAll()
}
