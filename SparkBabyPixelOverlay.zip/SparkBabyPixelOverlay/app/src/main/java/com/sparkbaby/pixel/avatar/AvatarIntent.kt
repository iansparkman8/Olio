package com.sparkbaby.pixel.avatar

sealed class AvatarIntent {
    object ComeHere : AvatarIntent()
    object GoAway : AvatarIntent()
    object Dance : AvatarIntent()
    object Sleep : AvatarIntent()
    object WakeUp : AvatarIntent()
    data class ChangeMood(val mood: MoodState) : AvatarIntent()
    data class Remember(val fact: String) : AvatarIntent()
    object ShowMemories : AvatarIntent()
}
