package com.sparkbaby.pixel.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val SparkDarkColorScheme = darkColorScheme(
    primary = NeonPurple,
    secondary = NeonCyan,
    tertiary = NeonMagenta,
    background = DarkBg,
    surface = CardBg,
    onPrimary = DarkBg,
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

@Composable
fun SparkBabyTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = SparkDarkColorScheme,
        typography = SparkTypography,
        content = content
    )
}
