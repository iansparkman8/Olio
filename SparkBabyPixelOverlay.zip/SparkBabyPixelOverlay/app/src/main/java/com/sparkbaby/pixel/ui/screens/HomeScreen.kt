package com.sparkbaby.pixel.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.sparkbaby.pixel.ui.components.PixelButton
import com.sparkbaby.pixel.ui.components.SparkPreview

@Composable
fun HomeScreen(
    onNavigateToPermissions: () -> Unit,
    onNavigateToControl: () -> Unit,
    onStartOverlay: () -> Unit,
    onStopOverlay: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("✨ Spark Baby ✨", style = MaterialTheme.typography.titleLarge)
        Text("Your pixel companion overlay", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))

        SparkPreview(modifier = Modifier.size(180.dp))

        Spacer(Modifier.height(16.dp))

        PixelButton(text = "Start Floating Companion", onClick = onStartOverlay)
        PixelButton(text = "Stop Companion", onClick = onStopOverlay, variant = "secondary")
        PixelButton(text = "Permission Wizard", onClick = onNavigateToPermissions, variant = "ghost")
        PixelButton(text = "Open Control Panel", onClick = onNavigateToControl)
    }
}
