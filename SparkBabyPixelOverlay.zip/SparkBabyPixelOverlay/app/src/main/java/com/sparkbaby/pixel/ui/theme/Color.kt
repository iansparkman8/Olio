package com.sparkbaby.pixel.ui.theme

import androidx.compose.ui.graphics.Color

val NeonPurple = Color(0xFFB450FF)
val NeonCyan = Color(0xFF50DCFF)
val NeonMagenta = Color(0xFFFF50C8)
val NeonYellow = Color(0xFFFFE650)
val DarkBg = Color(0xFF0F0A19)
val CardBg = Color(0xFF1A1530)
val TextPrimary = Color(0xFFE0E0FF)
