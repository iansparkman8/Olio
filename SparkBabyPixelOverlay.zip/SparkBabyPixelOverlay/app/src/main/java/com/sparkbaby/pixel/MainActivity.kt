package com.sparkbaby.pixel

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.sparkbaby.pixel.overlay.OverlayPermissionHelper
import com.sparkbaby.pixel.overlay.SparkOverlayService
import com.sparkbaby.pixel.ui.SparkBabyApp
import com.sparkbaby.pixel.ui.navigation.Routes
import com.sparkbaby.pixel.ui.theme.SparkBabyTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { _ ->
        // Re-check after user returns from settings
        checkAndStartOverlayIfAllowed()
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            checkOverlayPermissionAndStart()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SparkBabyTheme {
                SparkBabyApp(
                    onStartOverlay = { startOverlayFlow() },
                    onStopOverlay = { stopOverlayService() },
                    onRequestOverlayPermission = { requestOverlayPermission() }
                )
            }
        }
    }

    private fun startOverlayFlow() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permission = Manifest.permission.POST_NOTIFICATIONS
            when (ContextCompat.checkSelfPermission(this, permission)) {
                android.content.pm.PackageManager.PERMISSION_GRANTED -> {
                    checkOverlayPermissionAndStart()
                }
                else -> {
                    notificationPermissionLauncher.launch(permission)
                }
            }
        } else {
            checkOverlayPermissionAndStart()
        }
    }

    private fun checkOverlayPermissionAndStart() {
        if (OverlayPermissionHelper.hasOverlayPermission(this)) {
            startOverlayService()
        } else {
            requestOverlayPermission()
        }
    }

    private fun requestOverlayPermission() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        overlayPermissionLauncher.launch(intent)
    }

    private fun startOverlayService() {
        val intent = Intent(this, SparkOverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun stopOverlayService() {
        val intent = Intent(this, SparkOverlayService::class.java)
        stopService(intent)
    }

    private fun checkAndStartOverlayIfAllowed() {
        if (OverlayPermissionHelper.hasOverlayPermission(this)) {
            startOverlayService()
        }
    }
}
