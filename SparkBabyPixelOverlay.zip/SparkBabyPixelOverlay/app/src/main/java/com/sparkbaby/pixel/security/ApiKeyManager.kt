package com.sparkbaby.pixel.security

import android.content.Context

class ApiKeyManager(private val context: Context) {

    fun getOpenAiKey(): String? = SecureKeyStore.getKey(context, "openai_api_key")
    fun saveOpenAiKey(key: String) = SecureKeyStore.saveKey(context, "openai_api_key", key)

    fun getGenericKey(): String? = SecureKeyStore.getKey(context, "generic_api_key")
    fun saveGenericKey(key: String) = SecureKeyStore.saveKey(context, "generic_api_key", key)

    fun clearAllKeys() {
        SecureKeyStore.clearKey(context, "openai_api_key")
        SecureKeyStore.clearKey(context, "generic_api_key")
    }
}
