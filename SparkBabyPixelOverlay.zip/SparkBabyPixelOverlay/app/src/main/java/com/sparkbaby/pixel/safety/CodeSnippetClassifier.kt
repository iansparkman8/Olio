package com.sparkbaby.pixel.safety

object CodeSnippetClassifier {

    fun classify(code: String): RiskLevel {
        val lower = code.lowercase()
        return when {
            lower.contains("rm -rf") || lower.contains("format") -> RiskLevel.BLOCKED
            lower.contains("exec") || lower.contains("runtime.getruntime") -> RiskLevel.REVIEW_NEEDED
            else -> RiskLevel.SAFE
        }
    }
}
