package com.sparkbaby.pixel.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface LessonDao {
    @Insert
    suspend fun insert(lesson: LessonEntity)

    @Query("SELECT * FROM lessons ORDER BY learnedAt DESC")
    fun getAll(): Flow<List<LessonEntity>>
}
