package com.sparkbaby.pixel.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "avatar_forms")
data class AvatarFormEntity(
    @PrimaryKey val formId: String,
    val name: String,
    val currentLevel: Int = 1,
    val unlocked: Boolean = true
)
