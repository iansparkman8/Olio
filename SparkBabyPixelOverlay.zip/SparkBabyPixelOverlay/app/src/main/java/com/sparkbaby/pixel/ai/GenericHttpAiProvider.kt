package com.sparkbaby.pixel.ai

import com.sparkbaby.pixel.security.ApiKeyManager

class GenericHttpAiProvider(
    private val apiKeyManager: ApiKeyManager,
    private val baseUrl: String = "https://api.example.com/v1"
) : AiProvider {

    override suspend fun getReply(prompt: String, context: List<String>): AiReply {
        val key = apiKeyManager.getGenericKey()
        if (key.isNullOrBlank()) {
            return AiReply("Generic HTTP provider key missing in Settings.", "GenericHTTP", wasFiltered = true)
        }
        return AiReply(
            text = "[Generic HTTP] Placeholder reply. Implement real call + safety filter here.",
            fromProvider = "GenericHTTP"
        )
    }

    override fun getProviderName() = "Generic HTTP"
}
