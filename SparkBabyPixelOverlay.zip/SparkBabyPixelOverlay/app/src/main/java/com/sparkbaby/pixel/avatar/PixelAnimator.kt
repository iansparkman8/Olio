package com.sparkbaby.pixel.avatar

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class PixelAnimator {
    fun animateFrames(frameCount: Int, fps: Int = 8): Flow<Int> = flow {
        var frame = 0
        while (true) {
            emit(frame)
            frame = (frame + 1) % frameCount
            delay(1000L / fps)
        }
    }
}
