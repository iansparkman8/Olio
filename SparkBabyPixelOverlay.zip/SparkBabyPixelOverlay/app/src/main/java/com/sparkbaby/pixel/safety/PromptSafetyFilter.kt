package com.sparkbaby.pixel.safety

object PromptSafetyFilter {

    private val blockedKeywords = listOf(
        "hack", "exploit", "illegal", "steal", "password", "api key", "credit card"
    )

    fun analyze(prompt: String): RiskLevel {
        val lower = prompt.lowercase()
        if (blockedKeywords.any { lower.contains(it) }) {
            return RiskLevel.BLOCKED
        }
        if (lower.contains("code") || lower.contains("script")) {
            return RiskLevel.REVIEW_NEEDED
        }
        return RiskLevel.SAFE
    }

    fun filterReply(reply: String): String {
        // Simple redaction example
        return reply.replace(Regex("sk-[a-zA-Z0-9]+"), "[REDACTED_KEY]")
    }
}
