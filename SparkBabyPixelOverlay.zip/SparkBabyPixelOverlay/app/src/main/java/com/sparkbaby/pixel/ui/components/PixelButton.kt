package com.sparkbaby.pixel.ui.components

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.sparkbaby.pixel.ui.theme.NeonCyan
import com.sparkbaby.pixel.ui.theme.NeonPurple

@Composable
fun PixelButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    variant: String = "primary"
) {
    val colors = when (variant) {
        "primary" -> ButtonDefaults.buttonColors(containerColor = NeonPurple)
        "secondary" -> ButtonDefaults.buttonColors(containerColor = NeonCyan)
        else -> ButtonDefaults.outlinedButtonColors()
    }
    Button(
        onClick = onClick,
        modifier = modifier.padding(vertical = 4.dp),
        colors = colors
    ) {
        Text(text.uppercase())
    }
}
