package com.sparkbaby.pixel.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.sparkbaby.pixel.ui.components.PixelButton

@Composable
fun MemoryScreen(navController: NavController) {
    Column(Modifier.padding(16.dp)) {
        Text("Memories & Lessons", style = MaterialTheme.typography.titleLarge)
        Text("(Room DB content would list here in real impl)")

        Spacer(Modifier.height(16.dp))
        PixelButton("Clear All Memories (safe)", onClick = { /* clear via DAO */ })
        PixelButton("Back", onClick = { navController.popBackStack() })
    }
}
