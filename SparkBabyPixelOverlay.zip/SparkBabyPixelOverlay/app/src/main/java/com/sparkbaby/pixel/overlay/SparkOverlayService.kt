package com.sparkbaby.pixel.overlay

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.ServiceCompat
import com.sparkbaby.pixel.R
import com.sparkbaby.pixel.avatar.MoodState
import kotlinx.coroutines.*

class SparkOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var pixelView: PixelCompanionView? = null
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = OverlayNotification.createNotification(this)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(
                this,
                OverlayNotification.NOTIFICATION_ID,
                notification,
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                } else {
                    0
                }
            )
        } else {
            startForeground(OverlayNotification.NOTIFICATION_ID, notification)
        }
        return START_STICKY
    }

    private fun createOverlay() {
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            },
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 300
            width = 96.dpToPx()
            height = 96.dpToPx()
        }

        pixelView = PixelCompanionView(this).apply {
            layoutParams = params
            setOnTouchListenerForDrag(params)
            setOnClickListener {
                toggleExpanded(params)
            }
        }

        try {
            windowManager?.addView(pixelView, params)
            // Start idle behavior
            serviceScope.launch {
                delay(2000)
                pixelView?.startIdleWandering(params)
            }
        } catch (e: Exception) {
            // Permission not granted or other error - service will stop itself
            stopSelf()
        }
    }

    private fun toggleExpanded(params: WindowManager.LayoutParams) {
        pixelView?.let { view ->
            if (view.isExpanded) {
                view.collapse()
                params.width = 96.dpToPx()
                params.height = 96.dpToPx()
            } else {
                view.expand()
                params.width = 320.dpToPx()
                params.height = 420.dpToPx()
            }
            windowManager?.updateViewLayout(view, params)
        }
    }

    private fun Int.dpToPx(): Int = (this * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        pixelView?.let {
            windowManager?.removeView(it)
        }
        pixelView = null
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
