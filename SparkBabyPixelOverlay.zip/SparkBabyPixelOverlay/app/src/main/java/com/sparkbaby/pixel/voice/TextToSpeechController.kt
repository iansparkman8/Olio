package com.sparkbaby.pixel.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.*

class TextToSpeechController(context: Context) {

    private var tts: TextToSpeech? = null
    private var isReady = false

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
                isReady = true
            }
        }
    }

    fun speak(text: String) {
        if (isReady) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "spark_baby_utterance")
        }
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
