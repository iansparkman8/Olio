package com.sparkbaby.pixel.ai

import com.sparkbaby.pixel.data.SparkDatabase
import com.sparkbaby.pixel.security.ApiKeyManager

class AiRepository(
    private val database: SparkDatabase,
    private val apiKeyManager: ApiKeyManager
) {
    private val localProvider = LocalAiProvider(database)
    private val openAiProvider = OpenAiProvider(apiKeyManager)
    private val genericProvider = GenericHttpAiProvider(apiKeyManager)

    suspend fun getReply(
        providerType: AiProviderType,
        prompt: String,
        context: List<String> = emptyList()
    ): AiReply {
        val provider: AiProvider = when (providerType) {
            AiProviderType.LOCAL -> localProvider
            AiProviderType.OPENAI -> openAiProvider
            AiProviderType.GENERIC_HTTP -> genericProvider
        }
        return provider.getReply(prompt, context)
    }
}
