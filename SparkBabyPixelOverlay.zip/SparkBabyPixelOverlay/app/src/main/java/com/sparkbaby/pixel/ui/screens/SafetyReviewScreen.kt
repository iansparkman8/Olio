package com.sparkbaby.pixel.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.sparkbaby.pixel.ui.components.PixelButton

@Composable
fun SafetyReviewScreen(navController: NavController) {
    Column(Modifier.padding(16.dp)) {
        Text("Safety Review", style = MaterialTheme.typography.titleLarge)
        Text("Recent AI replies and code snippets are reviewed here before any action.")

        Spacer(Modifier.height(16.dp))
        Text("No blocked actions yet. All clear ✨")
        PixelButton("Back", onClick = { navController.popBackStack() })
    }
}
