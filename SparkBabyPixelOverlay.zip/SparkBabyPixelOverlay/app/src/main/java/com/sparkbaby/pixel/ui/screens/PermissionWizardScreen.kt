package com.sparkbaby.pixel.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.sparkbaby.pixel.ui.components.PixelButton
import com.sparkbaby.pixel.ui.components.PixelCard

@Composable
fun PermissionWizardScreen(navController: NavController) {
    Column(Modifier.padding(16.dp)) {
        Text("Permission Wizard", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(16.dp))

        PixelCard {
            Text("1. Display over other apps (SYSTEM_ALERT_WINDOW)")
            Text("Required for the floating companion to appear above everything.")
        }
        Spacer(Modifier.height(8.dp))
        PixelButton(text = "Open Overlay Settings", onClick = { /* launch intent in real impl */ })

        Spacer(Modifier.height(16.dp))
        PixelCard {
            Text("2. Notifications (POST_NOTIFICATIONS)")
            Text("Keeps the service alive reliably.")
        }
        PixelButton(text = "Grant Notification Permission", onClick = { /* request */ })

        Spacer(Modifier.height(16.dp))
        PixelButton(text = "Done - Back to Home", onClick = { navController.popBackStack() })
    }
}
