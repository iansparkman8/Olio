package com.sparkbaby.pixel.ai

enum class AiProviderType {
    LOCAL,
    OPENAI,
    GENERIC_HTTP
}
