package com.sparkbaby.pixel.commands

sealed class CommandResult {
    data class Success(val message: String, val action: CommandAction) : CommandResult()
    data class Error(val reason: String) : CommandResult()
    object RequiresConfirmation : CommandResult()
}
