package com.sparkbaby.pixel.avatar

import kotlin.random.Random

class MovementController {
    data class Position(var x: Int, var y: Int)

    fun calculateNextWanderPosition(current: Position, screenW: Int, screenH: Int): Position {
        val dx = Random.nextInt(-120, 120)
        val dy = Random.nextInt(-60, 60)
        return Position(
            (current.x + dx).coerceIn(20, screenW - 120),
            (current.y + dy).coerceIn(80, screenH - 200)
        )
    }
}
