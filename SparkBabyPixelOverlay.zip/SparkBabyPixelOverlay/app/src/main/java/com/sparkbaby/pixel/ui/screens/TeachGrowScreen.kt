package com.sparkbaby.pixel.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.sparkbaby.pixel.ui.components.PixelButton
import com.sparkbaby.pixel.ui.components.PixelTextField

@Composable
fun TeachGrowScreen(navController: NavController) {
    var input by remember { mutableStateOf("") }

    Column(Modifier.padding(16.dp)) {
        Text("Teach & Grow", style = MaterialTheme.typography.titleLarge)
        Text("Share facts, lessons or upgrades safely. Spark Baby learns locally first.")

        Spacer(Modifier.height(16.dp))
        PixelTextField(
            value = input,
            onValueChange = { input = it },
            label = "What should I remember?"
        )
        PixelButton("Teach this", onClick = {
            // In real: insert to Room via ViewModel + safety filter
            input = ""
        })

        Spacer(Modifier.height(24.dp))
        Text("Safe modes: Local-first • Prompt filtered • No auto code exec")
    }
}
