package com.sparkbaby.pixel.ui.navigation

object Routes {
    const val HOME = "home"
    const val PERMISSION_WIZARD = "permission_wizard"
    const val CONTROL_PANEL = "control_panel"
    const val TEACH_GROW = "teach_grow"
    const val MEMORIES = "memories"
    const val FORMS = "forms"
    const val SETTINGS = "settings"
    const val SAFETY_REVIEW = "safety_review"
}
