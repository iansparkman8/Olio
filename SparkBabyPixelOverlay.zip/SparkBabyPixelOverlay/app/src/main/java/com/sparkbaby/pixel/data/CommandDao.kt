package com.sparkbaby.pixel.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface CommandDao {
    @Insert
    suspend fun insert(cmd: CommandEntity)

    @Query("SELECT * FROM commands ORDER BY executedAt DESC LIMIT 50")
    fun getRecent(): Flow<List<CommandEntity>>
}
