package com.sparkbaby.pixel.avatar

class PersonalityEngine {
    var affectionLevel: Float = 0.5f
        private set

    fun onPositiveInteraction() {
        affectionLevel = (affectionLevel + 0.05f).coerceAtMost(1f)
    }

    fun onNegativeInteraction() {
        affectionLevel = (affectionLevel - 0.08f).coerceAtLeast(0f)
    }

    fun getCurrentQuirk(): String {
        return when {
            affectionLevel > 0.85f -> "loves you a lot"
            affectionLevel < 0.2f -> "feeling a bit distant"
            else -> "happy to be here"
        }
    }
}
