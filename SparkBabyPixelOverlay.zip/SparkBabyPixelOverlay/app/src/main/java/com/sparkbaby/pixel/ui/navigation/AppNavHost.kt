package com.sparkbaby.pixel.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.sparkbaby.pixel.ui.screens.*

@Composable
fun AppNavHost(navController: NavHostController, startOverlay: () -> Unit, stopOverlay: () -> Unit) {
    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                onNavigateToPermissions = { navController.navigate(Routes.PERMISSION_WIZARD) },
                onNavigateToControl = { navController.navigate(Routes.CONTROL_PANEL) },
                onStartOverlay = startOverlay,
                onStopOverlay = stopOverlay
            )
        }
        composable(Routes.PERMISSION_WIZARD) { PermissionWizardScreen(navController) }
        composable(Routes.CONTROL_PANEL) { ControlPanelScreen(navController) }
        composable(Routes.TEACH_GROW) { TeachGrowScreen(navController) }
        composable(Routes.MEMORIES) { MemoryScreen(navController) }
        composable(Routes.FORMS) { FormsScreen(navController) }
        composable(Routes.SETTINGS) { SettingsScreen(navController) }
        composable(Routes.SAFETY_REVIEW) { SafetyReviewScreen(navController) }
    }
}
