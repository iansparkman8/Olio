package com.sparkbaby.pixel.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "commands")
data class CommandEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val commandText: String,
    val action: String,
    val executedAt: Long = System.currentTimeMillis()
)
