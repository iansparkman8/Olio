package com.sparkbaby.pixel.ai

import com.sparkbaby.pixel.data.SparkDatabase
import kotlinx.coroutines.delay

class LocalAiProvider(
    private val database: SparkDatabase? = null
) : AiProvider {

    override suspend fun getReply(prompt: String, context: List<String>): AiReply {
        delay(120) // simulate thinking
        val lower = prompt.lowercase()
        val replyText = when {
            lower.contains("how are you") -> "I'm feeling sparkly today! How about you?"
            lower.contains("tell me a secret") -> "I remember you like pineapple on pizza... don't tell anyone."
            lower.contains("i love you") -> "Aww, I love spending time with you too!"
            else -> "That's interesting! Tell me more so I can remember it."
        }
        return AiReply(
            text = replyText,
            fromProvider = "LocalOffline",
            confidence = 0.6f
        )
    }

    override fun getProviderName() = "Local (Offline)"
}
