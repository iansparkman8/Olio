package com.sparkbaby.pixel.avatar

data class AvatarForm(
    val id: String,
    val name: String,
    val spritePrefix: String,
    val unlockLevel: Int = 1,
    val description: String = ""
)
