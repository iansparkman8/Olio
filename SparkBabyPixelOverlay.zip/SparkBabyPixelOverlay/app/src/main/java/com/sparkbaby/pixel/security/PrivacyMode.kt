package com.sparkbaby.pixel.security

enum class PrivacyMode {
    LOCAL_ONLY,      // Never sends anything to cloud
    BALANCED,        // Local first, cloud for complex queries with consent
    FULL_CLOUD       // All AI via chosen provider (user keys)
}
