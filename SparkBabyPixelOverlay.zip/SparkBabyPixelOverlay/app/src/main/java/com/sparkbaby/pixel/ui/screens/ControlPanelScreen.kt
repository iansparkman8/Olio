package com.sparkbaby.pixel.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.sparkbaby.pixel.avatar.MoodState
import com.sparkbaby.pixel.ui.components.MoodChip
import com.sparkbaby.pixel.ui.components.PixelButton

@Composable
fun ControlPanelScreen(navController: NavController) {
    var currentMood by remember { mutableStateOf(MoodState.IDLE) }

    Column(Modifier.padding(16.dp)) {
        Text("Control Panel", style = MaterialTheme.typography.titleLarge)
        Text("Current mood: ${currentMood.name}")

        Spacer(Modifier.height(16.dp))
        Text("Quick Mood Changes")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MoodChip("Happy", onClick = { currentMood = MoodState.HAPPY })
            MoodChip("Curious", onClick = { currentMood = MoodState.CURIOUS })
            MoodChip("Dance!", onClick = { currentMood = MoodState.DANCING })
        }

        Spacer(Modifier.height(24.dp))
        PixelButton("Open Teach & Grow", onClick = { navController.navigate("teach_grow") })
        PixelButton("View Memories", onClick = { navController.navigate("memories") })
        PixelButton("Safety Review", onClick = { navController.navigate("safety_review") })
    }
}
